import java.util.List;
import java.util.Random;

public class Train implements Runnable {
    private final int trainId;
    private final int inboundTrack;
    private final int outboundTrack;
    private final List<Integer> requiredSwitches;
    private final SwitchYard yard;
    private final Random random = new Random();

    public Train(int trainId, int inboundTrack, int outboundTrack, List<Integer> requiredSwitches, SwitchYard yard) {
        this.trainId = trainId;
        this.inboundTrack = inboundTrack;
        this.outboundTrack = outboundTrack;
        this.requiredSwitches = requiredSwitches;
        this.yard = yard;
    }

    @Override
    public void run() {
        while (true) {
            if (yard.acquireSwitches(requiredSwitches, trainId)) {
                try {
                    Thread.sleep(random.nextInt(2000) + 1000); // Simulate train moving
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                }

                System.out.println("Train " + trainId + ": Clear of yard control.");
                yard.releaseSwitches(requiredSwitches, trainId);
                System.out.println("@ @ @ TRAIN " + trainId + ": DISPATCHED @ @ @");

                Project2.markTrainDispatched(trainId); // Update train status

                break;
            }
            try {
                Thread.sleep(random.nextInt(1000) + 500); // Wait before retrying
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }
    }
}
