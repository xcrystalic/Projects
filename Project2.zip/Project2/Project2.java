/*
Name: Elvi Levonja
Course: CNT 4714 Spring 2025
Assignment title: Project 2 – Multi-threaded programming in Java
Date: February 16, 2025
*/

import java.io.*;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Project2 {
    private static final int MAX_TRAINS = 30;
    private static final int MAX_SWITCHES = 10;
    private static final List<TrainStatus> trainStatuses = new ArrayList<>();

    public static void main(String[] args) {
        System.out.println("$ $ $ TRAIN MOVEMENT SIMULATION BEGINS........... $ $ $");

        SwitchYard yard = new SwitchYard(MAX_SWITCHES);
        List<Train> trainList = loadTrainData("TheFleetFile.csv", "theYardFile.csv", yard);

        ExecutorService executor = Executors.newFixedThreadPool(MAX_TRAINS);
        for (Train train : trainList) {
            executor.execute(train);
        }

        executor.shutdown();
        while (!executor.isTerminated()) {}

        System.out.println("$ $ $ SIMULATION ENDS $ $ $");
        
        printFinalStatus();
    }

    private static List<Train> loadTrainData(String fleetFile, String yardFile, SwitchYard yard) {
        List<Train> trainList = new ArrayList<>();
        Map<String, List<Integer>> trackConfigurations = new HashMap<>();

        try (BufferedReader br = new BufferedReader(new FileReader(yardFile))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(",");
                String key = parts[0] + "-" + parts[4];  // "Inbound-Track,Outbound-Track"
                List<Integer> switches = Arrays.asList(Integer.parseInt(parts[1]), Integer.parseInt(parts[2]), Integer.parseInt(parts[3]));
                trackConfigurations.put(key, switches);
            }
        } catch (IOException e) {
            System.out.println("Error reading yard configuration file.");
        }

        try (BufferedReader br = new BufferedReader(new FileReader(fleetFile))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(",");
                int trainId = Integer.parseInt(parts[0]);
                int inboundTrack = Integer.parseInt(parts[1]);
                int outboundTrack = Integer.parseInt(parts[2]);

                String key = inboundTrack + "-" + outboundTrack;
                if (trackConfigurations.containsKey(key)) {
                    List<Integer> requiredSwitches = trackConfigurations.get(key);
                    trainList.add(new Train(trainId, inboundTrack, outboundTrack, requiredSwitches, yard));
                    trainStatuses.add(new TrainStatus(trainId, inboundTrack, outboundTrack, 
                        requiredSwitches != null ? requiredSwitches : new ArrayList<>(), false));

                } else {
                    System.out.println("*************\nTrain " + trainId + " is on permanent hold and cannot be dispatched.\n*************");
                    trainStatuses.add(new TrainStatus(trainId, inboundTrack, outboundTrack, new ArrayList<>(), false));
                }
            }
        } catch (IOException e) {
            System.out.println("Error reading fleet file.");
        }
        return trainList;
    }

    private static void printFinalStatus() {
        System.out.println("\nFINAL TRAIN DISPATCH STATUS:\n");
        System.out.printf("+------------+---------------+----------------+----------------------+------------+\n");
        System.out.printf("| Train ID   | Inbound Track | Outbound Track | Required Switches    | Status     |\n");
        System.out.printf("+------------+---------------+----------------+----------------------+------------+\n");
        for (TrainStatus status : trainStatuses) {
            status.printStatus();
        }
        System.out.printf("+------------+---------------+----------------+----------------------+------------+\n");
    }

    public static void markTrainDispatched(int trainId) {
        for (TrainStatus status : trainStatuses) {
            if (status.getTrainId() == trainId) {
                status.setDispatched(true);
                break;
            }
        }
    }
}


