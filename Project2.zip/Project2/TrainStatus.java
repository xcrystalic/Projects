import java.util.ArrayList;
import java.util.List;  

public class TrainStatus {
    private final int trainId;
    private final int inboundTrack;
    private final int outboundTrack;
    private final List<Integer> requiredSwitches;
    private boolean dispatched;

    public TrainStatus(int trainId, int inboundTrack, int outboundTrack, List<Integer> requiredSwitches, boolean dispatched) {
        this.trainId = trainId;
        this.inboundTrack = inboundTrack;
        this.outboundTrack = outboundTrack;
        this.requiredSwitches = requiredSwitches != null ? requiredSwitches : new ArrayList<>(); 
        this.dispatched = dispatched;
    }

    public void markAsDispatched() {
        this.dispatched = true;
    }

    public void printStatus() {
        System.out.printf("| %-10d | %-13d | %-14d | %-20s | %-10s |\n",
            trainId, inboundTrack, outboundTrack, requiredSwitches.isEmpty() ? "N/A" : requiredSwitches, dispatched ? "DISPATCHED" : "HOLD");
    }

    public int getTrainId() {
        return trainId;
    }

    public void setDispatched(boolean dispatched) {
        this.dispatched = dispatched;
    }
}
