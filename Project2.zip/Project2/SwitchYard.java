import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.locks.ReentrantLock;

public class SwitchYard {
    private final Map<Integer, ReentrantLock> switches = new HashMap<>();

    public SwitchYard(int numSwitches) {
        for (int i = 1; i <= numSwitches; i++) {
            switches.put(i, new ReentrantLock());
        }
    }

    public boolean acquireSwitches(List<Integer> requiredSwitches, int trainId) {
        List<Integer> acquiredSwitches = new ArrayList<>();

        for (int switchId : requiredSwitches) {
            if (!switches.get(switchId).tryLock()) {
                releaseSwitches(acquiredSwitches, trainId); 
                System.out.println("Train " + trainId + ": UNABLE TO LOCK switch " + switchId + ". Train will wait...");
                return false;
            }
            acquiredSwitches.add(switchId);
            System.out.println("Train " + trainId + ": HOLDS LOCK on Switch " + switchId);
        }

        System.out.println("Train " + trainId + ": HOLDS ALL NEEDED SWITCH LOCKS – Train movement begins.");
        return true;
    }

    public void releaseSwitches(List<Integer> switchesToRelease, int trainId) {
        for (int switchId : switchesToRelease) {
            ReentrantLock lock = switches.get(switchId);
            if (lock.isHeldByCurrentThread()) { 
                lock.unlock();
                System.out.println("Train " + trainId + ": Unlocks/releases lock on Switch " + switchId);
            } else {
                System.out.println("ERROR: Train " + trainId + " tried to release Switch " + switchId + " but does not hold the lock!");
            }
        }
    }
}
