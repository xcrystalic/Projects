// Initial references
const container = document.querySelector(".container");
const playerTurn = document.getElementById("playerTurn");
const message = document.getElementById("message");
let initialMatrix = Array(6).fill(0).map(() => Array(7).fill(0));
let currentPlayer = 1;

// Write function gameOverCheck
function gameOverCheck() {
  let count = 0;
  for (let innerArray of initialMatrix) {
    if (innerArray.every(val => val != 0)) {
      count += 1;
    } else {
      return false;
    }
  }
  if (count === 6) {
    message.innerText = "Game Over";
    return false;
  }
}

// Write function winCheck 
function winCheck(row, column) {
  if (checkHorizontal(row, column) || checkVertical(row, column) || checkPositiveDiagonal(row, column) || checkNegativeDiagonal(row, column)) {
    return true;
  }
  return false;
}

// Write function setPiece
function setPiece(startCount, colValue) {
  try {
    const rows = document.querySelectorAll(".grid-row");

    // Loop to find the first available row in the column
    while (startCount >= 0 && initialMatrix[startCount][colValue] !== 0) {
      startCount--;
    }

    // If no available row, throw error
    if (startCount < 0) {
      throw new Error();
    }

    // Set the piece in the available row
    let currentRow = rows[startCount].querySelectorAll(".grid-box");
    currentRow[colValue].classList.add("filled", `player${currentPlayer}`);
    initialMatrix[startCount][colValue] = currentPlayer;

    // Check if the current move results in a win
    if (winCheck(startCount, colValue)) {
      message.innerHTML = `Player <span>${currentPlayer}</span> wins`;
      return false;
    }
    gameOverCheck();
  } catch (e) {
    alert("Column full, select again");
  }
}

// Write function fillBox 
function fillBox(e) {
  let colValue = parseInt(e.target.getAttribute("data-value"));
  setPiece(5, colValue);
  currentPlayer = currentPlayer === 1 ? 2 : 1;
  playerTurn.innerHTML = `Player <span>${currentPlayer}</span>'s turn`;
}

// Write function createBoard 
function createBoard() {
  for (let innerArray in initialMatrix) {
    let outerDiv = document.createElement("div");
    outerDiv.classList.add("grid-row");
    outerDiv.setAttribute("data-value", innerArray);

    for (let j in initialMatrix[innerArray]) {
      initialMatrix[innerArray][j] = 0;
      let innerDiv = document.createElement("div");
      innerDiv.classList.add("grid-box");
      innerDiv.setAttribute("data-value", j);
      innerDiv.addEventListener("click", (e) => { fillBox(e); });
      outerDiv.appendChild(innerDiv);
    }
    container.appendChild(outerDiv);
  }
}

// Write function startGame 
function startGame() {
  currentPlayer = 1;
  container.innerHTML = '';
  createBoard();
  playerTurn.innerHTML = `Player <span>${currentPlayer}</span>'s turn`;
}

// Check Horizontal
function checkHorizontal(row, column) {
  for (let i = Math.max(0, column - 3); i <= Math.min(3, column); i++) {
    if (
      initialMatrix[row][i] === currentPlayer &&
      initialMatrix[row][i + 1] === currentPlayer &&
      initialMatrix[row][i + 2] === currentPlayer &&
      initialMatrix[row][i + 3] === currentPlayer
    ) {
      return true;
    }
  }
  return false;
}

// Check Vertical
function checkVertical(row, column) {
  for (let i = Math.max(0, row - 3); i <= Math.min(2, row); i++) {
    if (
      initialMatrix[i][column] === currentPlayer &&
      initialMatrix[i + 1][column] === currentPlayer &&
      initialMatrix[i + 2][column] === currentPlayer &&
      initialMatrix[i + 3][column] === currentPlayer
    ) {
      return true;
    }
  }
  return false;
}

// Check Positive Diagonal (bottom-right to top-left)
function checkPositiveDiagonal(row, column) {
  for (let i = -3; i <= 0; i++) {
    if (
      row + i >= 0 && column + i >= 0 &&
      row + i + 3 < initialMatrix.length && column + i + 3 < initialMatrix[0].length &&
      initialMatrix[row + i][column + i] === currentPlayer &&
      initialMatrix[row + i + 1][column + i + 1] === currentPlayer &&
      initialMatrix[row + i + 2][column + i + 2] === currentPlayer &&
      initialMatrix[row + i + 3][column + i + 3] === currentPlayer
    ) {
      return true;
    }
  }
  return false;
}

// Check Negative Diagonal (bottom-left to top-right)
function checkNegativeDiagonal(row, column) {
  for (let i = -3; i <= 0; i++) {
    if (
      row + i >= 0 && column - i >= 0 &&
      row + i + 3 < initialMatrix.length && column - i - 3 >= 0 &&
      initialMatrix[row + i][column - i] === currentPlayer &&
      initialMatrix[row + i + 1][column - i - 1] === currentPlayer &&
      initialMatrix[row + i + 2][column - i - 2] === currentPlayer &&
      initialMatrix[row + i + 3][column - i - 3] === currentPlayer
    ) {
      return true;
    }
  }
  return false;
}

window.onload = startGame;
