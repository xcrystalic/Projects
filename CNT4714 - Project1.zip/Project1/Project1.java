/* Name: Elvi Levonja
Course: CNT 4714 – Spring 2025
Assignment title: Project 1 – An Event-driven Enterprise Simulation
Date: Sunday January 26, 2025
*/

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import javax.swing.*;

public class Project1 extends JFrame implements ActionListener {

    private JFrame frame;
    private List<Item> inventory; // List to store inventory items
    private List<String> cart; // List to store items in the shopping cart
    private JTextField itemIdField, quantityField, detailsField, subtotalField;
    private JLabel cartCountLabel; // Label for the cart count
    private JLabel[] cartItemLabels; // Labels to display items in the cart
    private int itemCounter = 1; // item counter
    private JLabel itemIdLabel; // intialized here for item counter
    private JLabel quantityLabel; 



    public Project1() {
        inventory = readInventory("inventory.csv"); // Load inventory from CSV
        cart = new ArrayList<>(); // Initialize shopping cart

        // Set up main frame
        frame = new JFrame();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setTitle("Rio.com");
        frame.setSize(600, 600);
        frame.setLayout(new GridLayout(3, 1));

        // Top panel: User Entry
        JPanel userEntry = new JPanel();
        userEntry.setBackground(Color.DARK_GRAY);
        userEntry.setLayout(new GridLayout(4, 2, 10, 10));

        // Labels and text fields for user entry
        itemIdLabel = new JLabel("Enter item ID for item #1");
        itemIdLabel.setForeground(Color.WHITE);
        itemIdField = new JTextField();

        quantityLabel = new JLabel("Enter Quantity for item #1:");
        quantityLabel.setForeground(Color.YELLOW);
        quantityField = new JTextField();

        JLabel detailsLabel = new JLabel("Show Details for Item:");
        detailsLabel.setForeground(Color.CYAN);
        detailsField = new JTextField();
        detailsField.setEditable(false);

        JLabel subtotalLabel = new JLabel("Subtotal for Item:");
        subtotalLabel.setForeground(Color.RED);
        subtotalField = new JTextField();
        subtotalField.setEditable(false);

        // Add components to the user entry panel
        userEntry.add(itemIdLabel);
        userEntry.add(itemIdField);
        userEntry.add(quantityLabel);
        userEntry.add(quantityField);
        userEntry.add(detailsLabel);
        userEntry.add(detailsField);
        userEntry.add(subtotalLabel);
        userEntry.add(subtotalField);

        // Middle panel: Shopping Cart
        JPanel shoppingCart = new JPanel();
        shoppingCart.setBackground(Color.GRAY);
        shoppingCart.setLayout(new BorderLayout());

        cartCountLabel = new JLabel("Items in Cart: 0", JLabel.CENTER);
        cartCountLabel.setFont(new Font("Arial", Font.BOLD, 16));
        shoppingCart.add(cartCountLabel, BorderLayout.NORTH);

        JPanel cartItemsPanel = new JPanel();
        cartItemsPanel.setLayout(new GridLayout(5, 1, 5, 5));
        cartItemsPanel.setBackground(Color.LIGHT_GRAY);

        cartItemLabels = new JLabel[5];
        for (int i = 0; i < 5; i++) {
            cartItemLabels[i] = new JLabel("Empty", JLabel.CENTER);
            cartItemLabels[i].setOpaque(true);
            cartItemLabels[i].setBackground(Color.WHITE);
            cartItemLabels[i].setFont(new Font("Arial", Font.PLAIN, 14));
            cartItemsPanel.add(cartItemLabels[i]);
        }

        shoppingCart.add(cartItemsPanel, BorderLayout.CENTER);

        // Bottom panel: User Controls
        JPanel itemSearch = new JPanel();
        itemSearch.setBackground(Color.GREEN);
        itemSearch.setLayout(new GridLayout(3, 2, 10, 10));

        JButton searchButton = new JButton("Search Item");
        searchButton.addActionListener(this);

        JButton addItemButton = new JButton("Add to Cart");
        addItemButton.addActionListener(this);

        JButton deleteItemButton = new JButton("Delete Item");
        deleteItemButton.addActionListener(this); 

        JButton clearCartButton = new JButton("Clear Cart");
        clearCartButton.addActionListener(e -> clearCart());

        JButton checkOutButton = new JButton("Check Out");
        checkOutButton.addActionListener(e -> checkOut()); 

        JButton exitAppButton = new JButton("Exit");
        exitAppButton.addActionListener(e -> System.exit(0));

        // Add buttons to the bottom panel
        itemSearch.add(searchButton);
        itemSearch.add(addItemButton);
        itemSearch.add(deleteItemButton);
        itemSearch.add(clearCartButton);
        itemSearch.add(checkOutButton);
        itemSearch.add(exitAppButton);

        // Add panels to the frame
        frame.add(userEntry);
        frame.add(shoppingCart);
        frame.add(itemSearch);

        frame.setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String command = e.getActionCommand();

        if (command.equals("Search Item")) {
            String itemId = itemIdField.getText();
            Item item = findItemById(itemId);

            if (item != null) {
                detailsField.setText(item.getItemName() + " ($" + item.getPrice() + ")");
                subtotalField.setText(""); 
            } else {
                showError("Item not found in inventory");
            }
        } else if (command.equals("Add to Cart")) {
            String itemId = itemIdField.getText();
            String quantityText = quantityField.getText();
        
            try {
                int quantity = Integer.parseInt(quantityText);
                Item item = findItemById(itemId);
        
                if (item != null) {
                    if (item.isInStock() && quantity <= item.getAmountInStock()) {
                        double subtotal = item.getPrice() * quantity; // Calculate subtotal
                        cart.add(item.getItemName() + " (x" + quantity + ") - $" + subtotal);
                        updateCartDisplay();
                        subtotalField.setText("$" + subtotal); // Show subtotal
        
                        // Clear the user entry fields
                        itemIdField.setText(""); // Clear Item ID field
                        quantityField.setText(""); // Clear Quantity field
        
                        // Update the counter and item ID label
                        itemCounter++;
                        itemIdLabel.setText("Enter item ID for item #" + itemCounter);
                        quantityLabel.setText("Enter Quantity for item #" + itemCounter);

                    } else {
                        showError("Insufficient stock");
                    }
                } else {
                    showError("Item not found in inventory");
                }
            } catch (NumberFormatException ex) {
                showError("Invalid quantity");
            }
        
        } else if (command.equals("Delete Item")) {
            deleteLastItemFromCart(); // Call method to delete the last item
        }
    }

    // Find an item by its ID
    private Item findItemById(String itemId) {
        for (Item item : inventory) {
            if (item.getItemId().equals(itemId)) {
                return item;
            }
        }
        return null;
    }

    // Update the shopping cart display
    private void updateCartDisplay() {
        cartCountLabel.setText("Items in Cart: " + cart.size());
        for (int i = 0; i < cartItemLabels.length; i++) {
            if (i < cart.size()) {
                cartItemLabels[i].setText(cart.get(i));
            } else {
                cartItemLabels[i].setText("Empty");
            }
        }
    }

    // Clear the shopping cart
    private void clearCart() {
        cart.clear();
        updateCartDisplay();
        subtotalField.setText(""); // Clear subtotal when cart is cleared
    
        // Reset item counter and label
        itemCounter = 1;
        itemIdLabel.setText("Enter item ID for item #" + itemCounter);
        quantityLabel.setText("Enter Quantity for item #" + itemCounter);

    }
    

    // Method to delete the last item from the cart
    private void deleteLastItemFromCart() {
        if (!cart.isEmpty()) {
            cart.remove(cart.size() - 1); // Remove the last item
            updateCartDisplay(); // Update the display
        } else {
            showError("Cart is empty. No items to delete.");
        }
    }

    // Method to check out and generate invoice
    private void checkOut() {
        if (cart.isEmpty()) {
            showError("Cart is empty. Please add items to cart before checking out.");
            return;
        }
    
        // Generate unique transaction ID
        String transactionId = generateTransactionId();
    
        // Create invoice message
        StringBuilder invoice = new StringBuilder();
        invoice.append("Invoice\n");
        invoice.append("Transaction ID: ").append(transactionId).append("\n");
        invoice.append("Items:\n");
    
        double totalAmount = 0.0;
        for (String item : cart) {
            invoice.append(item).append("\n");
            // Extract subtotal from the item string and add to total
            String[] parts = item.split(" - \\$");
            if (parts.length > 1) {
                totalAmount += Double.parseDouble(parts[1]);
            }
        }
        invoice.append("Total Amount: $").append(totalAmount).append("\n");
        invoice.append("Thank you for your purchase!");
    
        // Show invoice message
        JOptionPane.showMessageDialog(frame, invoice.toString(), "Invoice", JOptionPane.INFORMATION_MESSAGE);
    
        // Write transaction to CSV
        writeTransactionToCSV(transactionId, totalAmount);
    
        // Clear the cart after checkout
        clearCart();
    
        // Reset item counter and label
        itemCounter = 1;
        itemIdLabel.setText("Enter item ID for item #" + itemCounter);
        quantityLabel.setText("Enter Quantity for item #" + itemCounter);
    }
    

    // Generate unique transaction ID based on current date and time
    private String generateTransactionId() {
        SimpleDateFormat sdf = new SimpleDateFormat("ddMMyyyyHHmmss");
        return sdf.format(new Date());
    }

    // Write transaction details to CSV file
    private void writeTransactionToCSV(String transactionId, double totalAmount) {
        try (PrintWriter writer = new PrintWriter(new FileWriter("transactions.csv", true))) {
            // Write header if the file is empty
            if (new java.io.File("transactions.csv").length() == 0) {
                writer.println("Transaction ID,Date,Time,Total Amount");
            }
            SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yy HH:mm:ss");
            String dateTime = dateFormat.format(new Date());
            writer.println(transactionId + "," + dateTime + "," + totalAmount);
        } catch (IOException e) {
            showError("Error writing to transactions.csv");
            e.printStackTrace();
        }
    }

    // Show error message in a pop-up dialog
    private void showError(String message) {
        JOptionPane.showMessageDialog(frame, message, "Error", JOptionPane.ERROR_MESSAGE);
    }

    // Method to read inventory CSV file
    private List<Item> readInventory(String filePath) {
        List<Item> inventoryList = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            System.out.println("Reading inventory from: " + filePath);
            String line;

            // Process all lines, including the first one
            while ((line = br.readLine()) != null) {
                String[] values = line.split(",");
                for (int i = 0; i < values.length; i++) {
                    values[i] = values[i].trim(); // Trim spaces
                }
                try {
                    int amountInStock = Integer.parseInt(values[3]);
                    double price = Double.parseDouble(values[4]);
                    // Create Item object and add to inventory
                    inventoryList.add(new Item(values[0], values[1], amountInStock > 0, amountInStock, price));
                } catch (NumberFormatException e) {
                    System.out.println("Error parsing line: " + Arrays.toString(values));
                    e.printStackTrace();
                }
            }
        } catch (IOException e) {
            showError("Error reading the inventory file: " + filePath);
            e.printStackTrace();
        }
        return inventoryList;
    }

    // Item class to hold inventory data
    static class Item {
        private String itemId;
        private String itemName;
        private boolean inStock;
        private int amountInStock;
        private double price;

        public Item(String itemId, String itemName, boolean inStock, int amountInStock, double price) {
            this.itemId = itemId;
            this.itemName = itemName;
            this.inStock = inStock;
            this.amountInStock = amountInStock;
            this.price = price;
        }

        public String getItemId() {
            return itemId;
        }

        public String getItemName() {
            return itemName;
        }

        public boolean isInStock() {
            return amountInStock > 0; // Check if in stock based on amount
        }

        public int getAmountInStock() {
            return amountInStock;
        }

        public double getPrice() {
            return price;
        }
    }

    public static void main(String[] args) {
        new Project1();
    }
}